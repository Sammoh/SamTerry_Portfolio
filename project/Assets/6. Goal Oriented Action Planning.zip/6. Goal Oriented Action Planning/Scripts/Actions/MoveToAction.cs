using System.Collections.Generic;
using UnityEngine;
#if UNITY_AI
using UnityEngine.AI;
#endif

namespace Sammoh.GOAP
{
    /// <summary>
    /// Generic "move to POI of type X" action.
    /// - Preconditions: a POI of the requested type must exist.
    /// - Effects: sets at_{poiType} = true when within stopDistance.
    ///
    /// Notes:
    /// - Attempts to use NavMeshAgent if present on the agent object; otherwise falls back to simple transform movement.
    /// - Does NOT clear the at_{poiType} flag; the subsequent consume action should clear it after use.
    /// </summary>
    public class MoveToAction : IAction
    {
        public string ActionType { get; private set; }
        public float Cost { get; private set; } = 1f;
        public bool IsExecuting { get; private set; }

        private readonly string poiType;
        private readonly float speed;
        private readonly float stopDistance;

        // Runtime
        private Transform agentTransform;
        private Transform target;
#if UNITY_AI
        private NavMeshAgent nav;
#endif
        private bool reached;

        /// <summary>
        /// Construct a MoveToAction.
        /// Provide the agent transform if possible; if null, the action will try to resolve it via world/utility.
        /// </summary>
        public MoveToAction(string poiType, Transform agentTransform = null, float speed = 2.5f, float stopDistance = 0.3f, float cost = 1f)
        {
            this.poiType = poiType;
            this.agentTransform = agentTransform;
            this.speed = speed;
            this.stopDistance = Mathf.Max(0.05f, stopDistance);
            this.Cost = Mathf.Max(0.001f, cost);
            this.ActionType = $"MoveTo({poiType})";
        }

        public bool CheckPreconditions(IAgentState agentState, IWorldState worldState)
        {
            // Agent transform may be provided, or we try to resolve it dynamically.
            if (agentTransform == null)
                agentTransform = AgentResolver.TryGetAgentTransform(agentState);

            if (agentTransform == null)
                return false;

            // Find nearest POI of this type
            if (!POIUtility.TryGetNearestPOI(poiType, agentTransform.position, out target))
                return false;

            return true;
        }

        public Dictionary<string, object> GetEffects()
        {
            // Planner uses this to know what bit this action satisfies.
            var key = $"at_{poiType}";
            return new Dictionary<string, object> { { key, true } };
        }

        public void StartExecution(IAgentState agentState, IWorldState worldState)
        {
            IsExecuting = true;
            reached = false;

            if (agentTransform == null)
                agentTransform = AgentResolver.TryGetAgentTransform(agentState);

            // Validate/refresh target
            if (target == null && agentTransform != null)
                POIUtility.TryGetNearestPOI(poiType, agentTransform.position, out target);

#if UNITY_AI
            if (agentTransform != null && target != null)
            {
                nav = agentTransform.GetComponent<UnityEngine.AI.NavMeshAgent>();
                if (nav != null && nav.isOnNavMesh)
                {
                    nav.isStopped = false;
                    nav.SetDestination(target.position);
                }
            }
#endif
        }

        public ActionResult UpdateExecution(IAgentState agentState, IWorldState worldState, float deltaTime)
        {
            if (!IsExecuting || agentTransform == null || target == null)
                return ActionResult.Failed;

            float dist = Vector3.Distance(agentTransform.position, target.position);
            if (dist <= stopDistance)
            {
                reached = true;
                return ActionResult.Success;
            }

            // Move
#if UNITY_AI
            if (nav != null && nav.isOnNavMesh)
            {
                if (nav.destination != target.position)
                    nav.SetDestination(target.position);
            }
            else
#endif
            {
                Vector3 dir = (target.position - agentTransform.position);
                float step = speed * Mathf.Max(0f, deltaTime);
                if (dir.sqrMagnitude > 0.0001f)
                {
                    Vector3 move = Vector3.ClampMagnitude(dir, step);
                    agentTransform.position += move;
                }
            }

            return ActionResult.Running;
        }

        public void CancelExecution()
        {
            IsExecuting = false;
#if UNITY_AI
            if (nav != null) nav.isStopped = true;
#endif
        }

        public void ApplyEffects(IAgentState agentState, IWorldState worldState)
        {
            IsExecuting = false;
#if UNITY_AI
            if (nav != null) nav.isStopped = true;
#endif
            if (reached && worldState != null)
            {
                // Set "at_{poiType}" = true
                worldState.SetFact($"at_{poiType}", true);
            }
        }

        public string GetDescription() => $"Move towards nearest '{poiType}' until within {stopDistance}m.";
    }

    /// <summary>
    /// Resolves agent Transform from an arbitrary IAgentState implementation.
    /// Modify this mapping if your IAgentState exposes a different API.
    /// </summary>
    internal static class AgentResolver
    {
        public static Transform TryGetAgentTransform(IAgentState agentState)
        {
            if (agentState == null) return null;

            // Common patterns we can try via reflection without hard coupling.
            // 1) Property named "Transform" or "AgentTransform"
            var tProp = agentState.GetType().GetProperty("Transform")
                       ?? agentState.GetType().GetProperty("AgentTransform");
            if (tProp != null)
            {
                var val = tProp.GetValue(agentState) as Transform;
                if (val != null) return val;
            }

            // 2) Field named "transform" or "agentTransform"
            var tField = agentState.GetType().GetField("transform")
                         ?? agentState.GetType().GetField("agentTransform");
            if (tField != null)
            {
                var val = tField.GetValue(agentState) as Transform;
                if (val != null) return val;
            }

            return null;
        }
    }
}
