using System.Collections.Generic;
using UnityEngine;

namespace Sammoh.GOAP
{
    /// <summary>
    /// Component to mark GameObjects as Points of Interest
    /// </summary>
    public class POIMarker : MonoBehaviour
    {
        [Header("POI Identity")]
        [SerializeField] private string poiTag = "kitchen"; // optional tag for DB queries

        [Header("Goals supported by this POI (drag Goal assets)")]
        [SerializeField] private List<GoalSO> supportedGoals = new();

        public string Tag
        {
            get => poiTag;
            set => poiTag = value;
        }

        public IReadOnlyList<GoalSO> SupportedGoals => supportedGoals;

        // Example: expose a fast check for planner/executor
        public bool SupportsGoalType(string goalType)
        {
            foreach (var g in supportedGoals)
                if (g != null && string.Equals(g.GoalType, goalType, System.StringComparison.OrdinalIgnoreCase))
                    return true;
            return false;
        }
    }
}
