// Assets/GOAP/Goals/GoalDatabase.cs
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Sammoh.GOAP {
public enum GoalId
{
    Idle,
    Hunger,
    Thirst,
    Sleep,
    Play,
    // add custom IDs here
}

[CreateAssetMenu(fileName = "GoalDatabase", menuName = "GOAP/Goal Database", order = 0)]
public class GoalDatabase : ScriptableObject
{
    [Header("Registered Goals (drag GoalSO assets here)")]
    [SerializeField] private List<GoalSO> goals = new();

    [Header("Optional Tags (for POIs, zones, etc.)")]
    [Tooltip("A mapping from tag to a set of goals commonly associated with that tag (e.g., 'kitchen' -> Hunger, Thirst).")]
    [SerializeField] private List<TagGoals> tagMappings = new();

    // Runtime lookups
    private Dictionary<string, GoalSO> _byType;     // key: GoalType
    private Dictionary<GoalId, GoalSO> _byId;       // key: enum
    private Dictionary<string, List<GoalSO>> _byTag; // key: tag

    [Serializable]
    public class TagGoals
    {
        public string tag;
        public List<GoalSO> goals = new();
    }

    #region Public API

    public IReadOnlyList<GoalSO> AllGoals => goals;

    public void InitializeLookups()
    {
        _byType = new Dictionary<string, GoalSO>(StringComparer.OrdinalIgnoreCase);
        _byId   = new Dictionary<GoalId, GoalSO>();
        _byTag  = new Dictionary<string, List<GoalSO>>(StringComparer.OrdinalIgnoreCase);

        foreach (var g in goals.Where(g => g != null))
        {
            if (!_byType.ContainsKey(g.GoalType))
                _byType[g.GoalType] = g;

            // Best-effort enum mapping by name match (optional)
            if (Enum.TryParse<GoalId>(g.name, ignoreCase: true, out var idByName))
                _byId[idByName] = g;
        }

        foreach (var map in tagMappings.Where(t => !string.IsNullOrWhiteSpace(t.tag)))
        {
            if (!_byTag.TryGetValue(map.tag, out var list))
            {
                list = new List<GoalSO>();
                _byTag[map.tag] = list;
            }
            foreach (var g in map.goals.Where(x => x != null))
                if (!list.Contains(g)) list.Add(g);
        }
    }

    /// <summary>Lookup by the IGoal.GoalType string.</summary>
    public GoalSO GetByType(string goalType)
    {
        if (_byType == null) InitializeLookups();
        return goalType != null && _byType.TryGetValue(goalType, out var g) ? g : null;
    }

    /// <summary>Lookup by enum ID. Requires name parity with asset or explicit editor wiring.</summary>
    public GoalSO GetById(GoalId id)
    {
        if (_byId == null) InitializeLookups();
        return _byId.TryGetValue(id, out var g) ? g : goals.FirstOrDefault(x => string.Equals(x.name, id.ToString(), StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Get all goals associated with a tag (used by POIs, rooms, etc.).</summary>
    public IReadOnlyList<GoalSO> GetByTag(string tag)
    {
        if (_byTag == null) InitializeLookups();
        return _byTag.TryGetValue(tag, out var list) ? list : Array.Empty<GoalSO>();
    }

    /// <summary>Return goals that can currently satisfy under the present state.</summary>
    public List<IGoal> GetSatisfiableGoals(IAgentState agent, IWorldState world)
    {
        return goals.Where(g => g != null && g.CanSatisfy(agent, world))
                    .Cast<IGoal>()
                    .ToList();
    }

    #endregion

#if UNITY_EDITOR
    private void OnValidate() => InitializeLookups();
#endif
}

}
