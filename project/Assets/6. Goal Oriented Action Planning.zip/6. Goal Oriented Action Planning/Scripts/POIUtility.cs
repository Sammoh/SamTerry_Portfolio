using UnityEngine;

namespace Sammoh.GOAP
{
    /// <summary>
    /// Simple helper to locate Points Of Interest by logical tag via POIMarker.
    /// Replace with your IWorldState registry if you already maintain one there.
    /// </summary>
    public static class POIUtility
    {
        public static bool TryGetNearestPOI(string poiType, Vector3 from, out Transform nearest)
        {
            nearest = null;
            float best = float.MaxValue;

            var markers = Object.FindObjectsOfType<POIMarker>();
            if (markers == null || markers.Length == 0) return false;

            for (int i = 0; i < markers.Length; i++)
            {
                var m = markers[i];
                if (m == null || !m.isActiveAndEnabled) continue;
                if (!string.Equals(m.Tag, poiType)) continue;

                float d = (m.transform.position - from).sqrMagnitude;
                if (d < best)
                {
                    best = d;
                    nearest = m.transform;
                }
            }

            return nearest != null;
        }
    }
}
